# Frogcrafting Hotbar
A Modern and aesthetic hotbar resource pack featuring adorable frogs and mushrooms, made for Frogcrafting!
https://discord.gg/H9V6FuVGfT - Garden Gals
https://discord.gg/frogcrafting - Frogcrafting

All Rights Reserved