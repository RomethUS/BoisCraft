
*Terms of use*:

With this recourcepack, YOU MAY (only with proper credit):

- Include Torchified in your mod (pack) or server
- Modify for personal use

With this resource pack, YOU MAY NOT:

- Redistribute this resource pack




p.s. you should totaly download colourful containers 
https://modrinth.com/resourcepack/colourful-containers-gui
https://modrinth.com/resourcepack/colourful-containers-dark-mode-gui



